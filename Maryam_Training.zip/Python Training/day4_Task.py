from urllib import response
import requests 
import re

class AWS():
    def __init__(self, domain):
       self.baseurl = '.s3.amazonaws.com'
       self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'}
       self.live=[]
       self.container=[]
       self.extracted=[]
       self.domain=domain.split(".")[0]
       
    def wordlist(self):
        words=open("./permutation.txt", 'r').read().splitlines()
       
        file=open("./editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("./editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()
        
        words=open("/Users/maryamalem/Desktop/permutation.txt", 'r').read().splitlines()
       
        file=open("/Users/maryamalem/Desktop/editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("/Users/maryamalem/Desktop/editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()
            
            
    def bruteforce(self):
        words=open("/Users/maryamalem/Desktop/editted.txt", 'r').read().splitlines()
        for dom in words:
                
            try:
                url="https://"+dom+self.baseurl
                result=requests.get(url)
                if result.status_code==200:
                    self.live.append(url)
        
                    
                    
            except:
                continue   
        
        print(self.live)
        
    def extracturl(self):
        for i in self.live:
            result=requests.get(i)
            pattern=r'<Key>(.*?)</Key>'
            links = re.findall(pattern, result.text)
            if result.status_code==200:
                self.extracted.append(links)
        print(self.extracted)
    
        


class GCP():
    
    def __init__(self, domain):
       self.baseurl = 'https://storage.googleapis.com/'
       self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'}
       self.domain=domain.split(".")[0]
       self.live=[]
       self.container=[]
       self.extracted=[]
       
    def wordlist(self):
        words=open("/Users/maryamalem/Desktop/permutation.txt", 'r').read().splitlines()
       
        file=open("/Users/maryamalem/Desktop/editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("/Users/maryamalem/Desktop/editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()
        
        words=open("/Users/maryamalem/Desktop/permutation.txt", 'r').read().splitlines()
       
        file=open("/Users/maryamalem/Desktop/editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("/Users/maryamalem/Desktop/editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()
        
        
    def bruteforce(self):
        words=open("/Users/maryamalem/Desktop/editted.txt", 'r').read().splitlines()
        for dom in words:
                
            try:
                url=self.baseurl+dom
                result=requests.get(url)
                if result.status_code==200:
                    self.live.append(url)
                    print(self.live)
                    
                    
            except:
                continue   
        
        
        
    def extracturl(self):
        for i in self.live:
            result=requests.get(i)
            pattern=r'<Key>(.*?)</Key>'
            links = re.findall(pattern, result.text)
            if result.status_code==200:
                self.extracted.append(links)
        print(self.extracted)
    
        

class azure():
   
    def __init__(self, domain):
        self.baseurl = '.blob.core.windows.net'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'}
        self.domain=domain.split(".")[0]
        self.live=[]
        self.container=[]
        self.extracted=[]
       
    def wordlist(self):
        words=open("/Users/maryamalem/Desktop/permutation.txt", 'r').read().splitlines()
       
        file=open("/Users/maryamalem/Desktop/editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("/Users/maryamalem/Desktop/editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()
        
        words=open("/Users/maryamalem/Desktop/permutation.txt", 'r').read().splitlines()
       
        file=open("/Users/maryamalem/Desktop/editted.txt", 'w') # first time we need to overwrite
        file.write(str(self.domain)+'\n')


        for w in words:    # first write $Company$word
            file.write(str(self.domain)+w+'\n')
        
        file.close()

        file=open("/Users/maryamalem/Desktop/editted.txt", 'a')

        for w in words:     #$word$company
            file.write(w + str(self.domain) + '\n')
        
        for w in words:     #$word$company$word
            file.write( w + str(self.domain) + w + '\n')

        for w in words:     #$word$word$company
            file.write(w + w + str(self.domain)+'\n')
        
        for w in words:     #$Company$word$word
            file.write(str(self.domain)+w+w + '\n')

        file.close()

    def bruteforce(self):
        words=open("editted.txt", 'r').read().splitlines()
        for dom in words:
            
            try:
                url="https://"+dom+self.baseurl
                
                result=requests.get(url)
                self.live.append(url)
                
                
            except:
                continue   
                    
    def bruteforecontainer(self):   
        words=open("containers.txt", 'r').read().splitlines()
        for i in self.live:
            for w in words:
                try:
                    url=f"{i}/{w}?restype=container&comp=list"
                    result=requests.get(url)
                    if result.status_code==200:
                            self.container.append(url)

                except:
                    continue
        print(self.container)        
    def extracturl(self):
        for i in self.container:
            result=requests.get(i)
            pattern=r'<Url>(.*?)</Url>'
           
            links = re.findall(pattern, result.text)
            self.extracted.append(links)
        print(self.extracted)
    
        


def Task4(domain):
    print(" bruteforcing for azure ")
    obj1=azure(domain)
    obj1.wordlist()
    obj1.bruteforce()
    obj1.bruteforecontainer()
    print("")
    obj1.extracturl()
    print(" bruteforcing for GCP ")
    obj2=GCP(domain)
    obj2.wordlist()
    obj2.bruteforce()
    obj2.extracturl()
    
    print(" bruteforcing for AWS ")
    obj3=AWS(domain)
    obj3.wordlist()
    obj3.bruteforce()
    obj3.extracturl()


                

