class calculator:
    def calculation(self,x,y,op):
        match op:
            case '+':
                return x+y
            case '-':
                return x-y
            case '*':
                return x*y
            case '/':
                return x/y
            
            
       
            
x=int(input("enter 1st number "))
y= int(input("enter 2nd number "))
op=str(input("enter the operator "))

my_calculator=calculator()
result=my_calculator.calculation(x,y,op)
print(result)




        
        
        
    
    
        
    