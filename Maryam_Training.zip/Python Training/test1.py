import requests
import re

class RapidDNS:
    def __init__(self, domain):
        self.domain = domain

    def subdomains(self):
        url = f"https://rapiddns.io/subdomain/{self.domain}#result"
        response = requests.get(url)
        
        pattern = rf"[A-Za-z]+\.{self.domain}"
        sub = re.findall(pattern,response.text)
     
        temp = []
        #print (response.text)
        for line in sub:
            if self.domain in line:
                temp.append(line)

        sanitized=[]
        for line in temp:
            if not line in sanitized:
                sanitized.append(line)            
            
        return sanitized

class Cert:
    def __init__(self,domain):
        self.domain=domain
        
    def subdomains(self):
        url = f"https://crt.sh/?q={self.domain}"
        response = requests.get(url)

        pattern = rf"[A-Za-z0-9]+\.{self.domain}"
        sub = re.findall(pattern,response.text)
        #print (response.text)
        temp = []
        #print (response.text)
        for line in sub:
            if self.domain in line:
                temp.append(line)
       
        sanitized=[]
        for line in temp:
            if line not in sanitized:
                sanitized.append(line)   
                
        return sanitized

    def newfunction(self):
        url = f"https://crt.sh/?q={self.domain}&output=json"
        result1 = requests.get(url)
        result2= result1.json()
        
        finalresult = []
        for i in result2:
            finalresult.append(i["common_name"] )
    
        unique=[]
        for line in finalresult:
            if line not in unique:
                unique.append(line)
        for line in unique:
            print(line)        



        
    
    
if __name__ == "__main__":

    domain=input("please enter your domain ")
    rapid_dns = RapidDNS(domain)
    rapid_subdomains = rapid_dns.subdomains()

    obj2=Cert(domain)  
    obj2_subdomains=obj2.subdomains()
    combined=obj2_subdomains+rapid_subdomains
    unique=[]
    up=[]

    for line in combined: 
        if not line in unique:
            unique.append(line)
    for line in unique:      
        print(line)  

    for line in unique:
        try: 
            response=requests.get(f"https://{line}")
            up.append(line)
        except:
            continue

    print("up hosts are",up)
         
  

    print("using json ")
    obj2=Cert("google.com")
    print(obj2.newfunction())
