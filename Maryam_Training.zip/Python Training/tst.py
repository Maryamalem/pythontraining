import re
import requests

class Crawling:
    def __init__(self, domain):
        self.domain = domain

    def get_urls(self):
        list_of_urls = []
        url = f"https://{self.domain}"
        
        try:
            response = requests.get(url)
            if response.status_code == 200:
                pattern = r'href=["\'](.*?)["\']'
                links = re.findall(pattern, response.text)
                for link in links:
                    if self.domain in link:
                        list_of_urls.append(link)
        except Exception as e:
            print("An error occurred:", e)

        return list_of_urls

# Example usage:
if __name__ == "__main__":
    domain = input("Enter the domain to crawl (e.g., example.com): ")
    crawler = Crawling(domain)
    urls = crawler.get_urls()
    print("Links found:")
    for url in urls:
        print(url)
