import os
import time 
import requests
import re
from selenium import webdriver 
from selenium.webdriver.chrome.options import Options



class bruteforcer():
    def __init__(self, domain):
        self.domain=domain
    def islive(self):
        livedomains=[]
        
        domain=open("list.txt", "r")
        line=domain.readlines()
        
        for i in range(1000):
            line[i]=line[i].strip()
            url=f"https://{line[i]}.{self.domain}" 
            
            
            try:
                result=requests.get(url)
                livedomains.append(url)
                print(url)
            except:
                continue

       


class Crawling:
    def __init__(self, domain):
        self.list_of_urls=[]
        self.domain = domain

    def get_urls(self):
        list_of_urls = []
        url = f"https://{self.domain}"
        
        try:
            for i in range(100):
                response = requests.get(url)
                if response.status_code == 200:
                    pattern = r'href=["\'](.*?)["\']'
                    links = re.findall(pattern, response.text)
                    for link in links:
                        if self.domain in link:
                            list_of_urls.append(link)
        except Exception as e:
            print("An error occurred:", )

        
    
    
        for i in list_of_urls:
            print(i)
            response = requests.get(i)
            if response.status_code == 200:
                pattern = r'href=["\'](.*?)["\']'
                links = re.findall(pattern, response.text)
                for link in links:
                    if self.domain in link and link not in self.list_of_urls:
                        self.list_of_urls.append(link)
            
    
       
        return list_of_urls
    
    
class scrnshot():
    def take(self):
        path = "./scrn/"

        domlist=open("dom.txt", "r")
        domains=domlist.readlines()
        #print(domains)
        if os.path.exists(path):
            files=os.listdir(path)
            for file in files:
                name=path+file
                os.remove(name)
        else:
            os.mkdir(path)
        for domain in domains:
            try:
                domain=domain.strip()
                Chrome_options = Options()
                Chrome_options.add_argument('--log-level=3')
                driver = webdriver.Chrome()
                driver.set_page_load_timeout(30)
                driver.get('https://'+domain)
                driver.save_screenshot("/Users/maryamalem/Desktop/scrn/"+domain+'.png')
                print(f"took screenshot for {domain}")
                driver.quit()
                
            except:
                print(f"couldn't take a screenshot for {domain} due to issues with the server!!")
        print("done getting screenshots")
            
            
        
    
def Task3(domain):
   print(f"brute forcing {domain}") 
   object1=bruteforcer(domain)
 
   print("active domains are ")
   object1.islive()
   print("crawled domains are",)
   
   crawler = Crawling(domain)
   urls = crawler.get_urls()
   for url in urls:
        print(url)
    
   print("screenshotitng ")
   object3=scrnshot()
   object3.take()
    
    
    
                    
                
            
           
        
        
    