import day4_Task
import day3_task_Maryam
import maryam_task2
import argparse




if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description='choese the Mode: Active/Passive and the Domain  ')
    parser.add_argument('Mode', type=str, help='Reconnaissance Mode')
    parser.add_argument('Domain', type=str, help='Victim Domain')
    args = parser.parse_args()
    if args.Mode == 'passive':
        maryam_task2.task2(args.Domain)
       
    elif args.Mode == 'active':
        day3_task_Maryam.Task3(args.Domain)
        day4_Task.Task4(args.Domain)
        
    
    